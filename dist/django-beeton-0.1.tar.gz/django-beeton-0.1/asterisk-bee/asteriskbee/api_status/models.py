from django.db import models

# Create your models here.

##Creamos un modelos para guardar los datos de las estadisticas del uso de recursos
#class marcas_graficas(models.Model):

	#Indica el tipo de estadistica (cada grafica es de un tipo)
#	tipo = models.CharField(max_length=80)

	#Guardamos la fecha y hora de la marca, siempre sera la fecha y hora actual
#	fecha_hora = models.DateTimeField(auto_now=True)

	#Guardamos el valor de la marca
#	valor = models.FloatField()

#	def __str__(self):
#		return "Estadisticas de tipo:"+self.tipo 



