#!/usr/bin/env python2.6

###############################################################################
# APLICAION QUE PERMITE LLAMAR A LA VEZ A UN GRUPO DETERMINADO DE EXTENSIONES #
#                                                                             #  
# El unico parametro que recibe del panel beeton es la lista del grupo de     #
# de extensiones separadas por comas, en formato: 123,222,423                 #
###############################################################################

from asterisk.agi import *
import sys

#importamos las funciones basicas de accesos a la base de datos
from funciones_basicas import *

def grupo_llamadas():

    miagi = AGI()
	###Sacamos el id de la linea
    id_linea = get_id_linea(miagi.env['agi_context'],miagi.env['agi_extension'],miagi.env['agi_priority'])

	##Comprobamos antes que la linea NO este comentada
    if get_commented_linea(id_linea) == '0':

        miagi.verbose("--------------Llamada a Grupo de llamadas utilizando AGI en python--------------")
        ext_dest = miagi.env['agi_extension']
        callerId = miagi.env['agi_callerid']
        cad = "---->Llamada desde--->"+callerId+" hacia--->"+ext_dest
        miagi.verbose("%s" % cad)

        if str(get_lista_param(id_linea)[0]) != "":
            lista_extensiones_grupo = str(get_lista_param(id_linea)[0]).split(',')
            sin_param = 0
        else:
            sin_param = 1
            cad_error = "---ERROR--- La aplicacion del grupo de llamadas del contexto "+miagi.env['agi_context']+" asociada a la extension "+ext_dest+" tiene el grupo de llamadas vacio"
            miagi.verbose("%s" % cad_error)

        opcion_dial = ""

        if sin_param == 0 and len(lista_extensiones_grupo) == 1:
            opcion_dial = get_tipo_exten(lista_extensiones_grupo[0]) + "/" + str(lista_extensiones_grupo[0]) + ",90,m,r"
        elif sin_param == 0 and len(lista_extensiones_grupo) > 1:
            for i in range(len(lista_extensiones_grupo)):
                opcion_dial = opcion_dial + get_tipo_exten(lista_extensiones_grupo[i]) + "/" + str(lista_extensiones_grupo[i])
                if i == len(lista_extensiones_grupo)-1:
                    opcion_dial = opcion_dial + ",90,m,r"
                else:
                    opcion_dial = opcion_dial + "&"


        ###Ver todos los parametroes de la api DIAL
        ##http://www.voip-info.org/wiki/view/Asterisk+cmd+Dial

        miagi.verbose("----OPCION-DIAL--- %s" % opcion_dial)

        if opcion_dial != "":
            miagi.answer()


		    ##Para evitar que el script termine al terminar la llamada a la aplicacion Dial####
            miagi.set_variable('AGISIGHUP','no')
            ###################################################################################

            miagi.appexec('dial', opcion_dial)

            miagi.set_variable('AGISIGHUP','yes')
            siguiente_prio = int(miagi.env['agi_priority'])+1
            miagi.goto_on_exit(miagi.env['agi_context'],ext_dest,str(siguiente_prio))

        miagi.verbose("-----------------------------------------------------------")

    else:
        cad = "ESTA COMENTADA! - La linea de grupo de llamadas del contexto->"+miagi.env['agi_context']+ " de la extencion->"+miagi.env['agi_extension']+" y prioridad->"+miagi.env['agi_priority']

        miagi.verbose("%s" % cad)


if __name__ == "__main__":
    grupo_llamadas()
